package clinic;

import java.time.LocalDate;
import java.util.*;

public class KlinikApp {
    private final Scanner sc = new Scanner(System.in);
    private final List<Reservation> reservations = new ArrayList<>();

    public static void main(String[] args) {
        new KlinikApp().run();
    }

    private void run() {
        while (true) {
            System.out.println("\n=== MENU ===");
            System.out.println("1. Tambah Reservasi");
            System.out.println("2. Lihat Reservasi");
            System.out.println("3. Edit Reservasi");
            System.out.println("4. Hapus Reservasi");
            System.out.println("0. Keluar");
            System.out.print("Pilihan: ");
            switch (sc.nextLine()) {
                case "1" -> addReservation();
                case "2" -> showReservations();
                case "3" -> editReservation();
                case "4" -> deleteReservation();
                case "0" -> { System.out.println("Terima kasih!"); return; }
                default  -> System.out.println("Input tidak valid!");
            }
        }
    }

    private void addReservation() {
        System.out.print("Nama pasien  : ");
        String nama = sc.nextLine().trim();
        Service svc  = chooseService();
        System.out.print("Tanggal (YYYY-MM-DD): ");
        LocalDate date = LocalDate.parse(sc.nextLine().trim());
        if (date.isBefore(LocalDate.now())) {
            System.out.println("⚠️ Tanggal tidak boleh di masa lalu!");
            return;
        }
        reservations.add(new Reservation(new Patient(nama), svc, date));
        System.out.println("✔ Reservasi berhasil disimpan!");
    }

    private Service chooseService() {
        System.out.println("Pilihan layanan: 1) Umum  2) Gigi  3) Spesialis");
        System.out.print("Masukkan nomor layanan: ");
        return switch (sc.nextLine().trim()) {
            case "1" -> new GeneralService();
            case "2" -> new DentalService();
            case "3" -> new SpecialistService();
            default  -> { System.out.println("Default: Umum"); yield new GeneralService(); }
        };
    }

    private void showReservations() {
        if (reservations.isEmpty()) {
            System.out.println("~ Belum ada reservasi ~");
            return;
        }
        System.out.println("\nNo | Tanggal | Pasien | Layanan | Biaya");
        System.out.println("---------------------------------------------");
        for (int i = 0; i < reservations.size(); i++) {
            System.out.println((i + 1) + ". " + reservations.get(i));
        }
    }

    private void editReservation() {
        showReservations();
        if (reservations.isEmpty()) return;

        System.out.print("Pilih nomor reservasi yang ingin diedit: ");
        int idx = Integer.parseInt(sc.nextLine()) - 1;
        if (idx < 0 || idx >= reservations.size()) {
            System.out.println("⚠️ Nomor tidak valid.");
            return;
        }

        Reservation old = reservations.get(idx);
        System.out.println("Edit untuk: " + old);

        System.out.print("Nama baru (kosongkan jika tidak ingin ubah): ");
        String newName = sc.nextLine().trim();
        if (!newName.isEmpty()) {
            old = new Reservation(new Patient(newName), old.getService(), old.getDate());
        }

        System.out.print("Ubah tanggal? (y/n): ");
        if (sc.nextLine().equalsIgnoreCase("y")) {
            System.out.print("Tanggal baru (YYYY-MM-DD): ");
            LocalDate dateBaru = LocalDate.parse(sc.nextLine().trim());
            if (dateBaru.isBefore(LocalDate.now())) {
                System.out.println("⚠️ Tanggal tidak boleh lampau.");
                return;
            }
            old = new Reservation(old.getPatient(), old.getService(), dateBaru);
        }

        System.out.print("Ubah layanan? (y/n): ");
        if (sc.nextLine().equalsIgnoreCase("y")) {
            Service newSvc = chooseService();
            old = new Reservation(old.getPatient(), newSvc, old.getDate());
        }

        reservations.set(idx, old);
        System.out.println("✔ Data berhasil diperbarui.");
    }

    private void deleteReservation() {
        showReservations();
        if (reservations.isEmpty()) return;

        System.out.print("Pilih nomor reservasi yang ingin dihapus: ");
        int idx = Integer.parseInt(sc.nextLine()) - 1;
        if (idx < 0 || idx >= reservations.size()) {
            System.out.println("⚠️ Nomor tidak valid.");
            return;
        }

        reservations.remove(idx);
        System.out.println("✔ Reservasi berhasil dihapus.");
    }
}
