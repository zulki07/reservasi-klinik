package clinic;

public class GeneralService implements Service {
    @Override
    public String getName() { return "Umum"; }
    @Override
    public double getPrice() { return 50000; }
}
