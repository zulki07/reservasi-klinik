package clinic;

public interface Service {
    String getName();
    double getPrice();
}
