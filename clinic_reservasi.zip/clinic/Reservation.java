package clinic;

import java.time.LocalDate;

public class Reservation {
    private final Patient patient;
    final Service service;
    final LocalDate date;

    public Reservation(Patient patient, Service service, LocalDate date) {
        this.patient = patient;
        this.service = service;
        this.date = date;
    }

    public Patient getPatient() { return patient; }
    public Service getService() { return service; }
    public LocalDate getDate() { return date; }

    @Override
    public String toString() {
        return String.format("%s | %s | %s | Rp%,.0f",
                date, patient.getName(), service.getName(), service.getPrice());
    }
}
