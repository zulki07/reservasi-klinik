package clinic;

public class DentalService implements Service {
    @Override
    public String getName() { return "Gigi"; }
    @Override
    public double getPrice() { return 75000; }
}
