package clinic;

public class SpecialistService implements Service {
    @Override
    public String getName() { return "Spesialis"; }
    @Override
    public double getPrice() { return 120000; }
}
